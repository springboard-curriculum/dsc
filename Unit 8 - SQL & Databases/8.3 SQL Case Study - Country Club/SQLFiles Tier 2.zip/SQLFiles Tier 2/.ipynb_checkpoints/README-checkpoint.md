# Instructions

- `sqlite_db_pythonsqlite.db` - This is the database file you are looking to use python to write SQL queries against.
- `SQLTask Tier 2.sql` - This is a text file with the list of questions we are looking to answer via SQL queries on `sqlite_db_pythonsqlite.db`. 